import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * Form untuk mengelola data mahasiswa
 * @author ACER
 */
public class DataMahasiswaForm extends javax.swing.JFrame {
    
    // List untuk menyimpan data mahasiswa
    private List<Mahasiswa> dataMahasiswa;
    private DefaultTableModel tableModel;
    private int selectedRow = -1;

    /**
     * Creates new form DataMahasiswaForm
     */
    public DataMahasiswaForm() {
        dataMahasiswa = new ArrayList<>();
        initComponents();
        setupTable();
        setupButtonGroup();
        clearForm();
    }
    
    // Setup tabel
    private void setupTable() {
        String[] columnNames = {"NIM", "Nama", "Alamat", "Jenis Kelamin", "Phone", "Prodi"};
        tableModel = new DefaultTableModel(columnNames, 0);
        tblMahasiswa.setModel(tableModel);
        
        // Event listener untuk seleksi baris tabel
        tblMahasiswa.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                selectedRow = tblMahasiswa.getSelectedRow();
                if (selectedRow >= 0) {
                    loadDataToForm(selectedRow);
                }
            }
        });
    }
    
    // Setup button group untuk radio button
    private void setupButtonGroup() {
        bgJenisKelamin.add(rbPria);
        bgJenisKelamin.add(rbWanita);
    }
    
    // Load data dari tabel ke form
    private void loadDataToForm(int row) {
        if (row >= 0 && row < dataMahasiswa.size()) {
            Mahasiswa mhs = dataMahasiswa.get(row);
            txtNIM.setText(mhs.getNim());
            txtNAMA.setText(mhs.getNama());
            txtALAMAT.setText(mhs.getAlamat());
            txtPHONE.setText(mhs.getPhone());
            txtPRODI.setText(mhs.getProdi());
            
            if ("Pria".equals(mhs.getJenisKelamin())) {
                rbPria.setSelected(true);
            } else {
                rbWanita.setSelected(true);
            }
        }
    }
    
    // Event handler untuk tombol SIMPAN
    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {
        simpanData();
    }
    
    // Event handler untuk tombol UBAH
    private void btnUbahActionPerformed(java.awt.event.ActionEvent evt) {
        ubahData();
    }
    
    // Event handler untuk tombol HAPUS
    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {
        hapusData();
    }
    
    // Event handler untuk tombol BERSIHKAN
    private void btnBersihkanActionPerformed(java.awt.event.ActionEvent evt) {
        clearForm();
    }
    
    // Event handler untuk tombol KELUAR
    private void btnKeluarActionPerformed(java.awt.event.ActionEvent evt) {
        System.exit(0);
    }
    
    // Event handler untuk tombol CETAK
    private void btnCetakActionPerformed(java.awt.event.ActionEvent evt) {
        cetakData();
    }
    
    // Method untuk menyimpan data
    private void simpanData() {
        // Validasi input
        if (txtNIM.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "NIM harus diisi!");
            txtNIM.requestFocus();
            return;
        }
        
        if (txtNAMA.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama harus diisi!");
            txtNAMA.requestFocus();
            return;
        }
        
        // Cek apakah NIM sudah ada
        String nim = txtNIM.getText().trim();
        for (Mahasiswa mhs : dataMahasiswa) {
            if (mhs.getNim().equals(nim)) {
                JOptionPane.showMessageDialog(this, "NIM sudah ada! Gunakan NIM yang berbeda.");
                txtNIM.requestFocus();
                return;
            }
        }
        
        // Cek jenis kelamin
        String jenisKelamin = "";
        if (rbPria.isSelected()) {
            jenisKelamin = "Pria";
        } else if (rbWanita.isSelected()) {
            jenisKelamin = "Wanita";
        } else {
            JOptionPane.showMessageDialog(this, "Pilih jenis kelamin!");
            return;
        }
        
        // Buat objek mahasiswa baru
        Mahasiswa mahasiswa = new Mahasiswa(
            nim,
            txtNAMA.getText().trim(),
            txtALAMAT.getText().trim(),
            jenisKelamin,
            txtPHONE.getText().trim(),
            txtPRODI.getText().trim()
        );
        
        // Tambahkan ke list dan tabel
        dataMahasiswa.add(mahasiswa);
        addToTable(mahasiswa);
        
        // Bersihkan form
        clearForm();
        
        JOptionPane.showMessageDialog(this, "Data berhasil disimpan!");
    }
    
    // Method untuk mengubah data
    private void ubahData() {
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan diubah!");
            return;
        }
        
        // Validasi input (sama seperti simpan)
        if (txtNIM.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "NIM harus diisi!");
            txtNIM.requestFocus();
            return;
        }
        
        if (txtNAMA.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama harus diisi!");
            txtNAMA.requestFocus();
            return;
        }
        
        String jenisKelamin = "";
        if (rbPria.isSelected()) {
            jenisKelamin = "Pria";
        } else if (rbWanita.isSelected()) {
            jenisKelamin = "Wanita";
        } else {
            JOptionPane.showMessageDialog(this, "Pilih jenis kelamin!");
            return;
        }
        
        // Update data
        Mahasiswa mhs = dataMahasiswa.get(selectedRow);
        mhs.setNim(txtNIM.getText().trim());
        mhs.setNama(txtNAMA.getText().trim());
        mhs.setAlamat(txtALAMAT.getText().trim());
        mhs.setJenisKelamin(jenisKelamin);
        mhs.setPhone(txtPHONE.getText().trim());
        mhs.setProdi(txtPRODI.getText().trim());
        
        // Update tabel
        updateTable();
        clearForm();
        
        JOptionPane.showMessageDialog(this, "Data berhasil diubah!");
    }
    
    // Method untuk menghapus data
    private void hapusData() {
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan dihapus!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Apakah Anda yakin ingin menghapus data ini?", 
            "Konfirmasi Hapus", 
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            dataMahasiswa.remove(selectedRow);
            updateTable();
            clearForm();
            JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
        }
    }
    
    // Method untuk mencetak data
    private void cetakData() {
        if (dataMahasiswa.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk dicetak!");
            return;
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("=== DATA MAHASISWA ===\n\n");
        
        for (int i = 0; i < dataMahasiswa.size(); i++) {
            Mahasiswa mhs = dataMahasiswa.get(i);
            sb.append("Data ke-").append(i + 1).append(":\n");
            sb.append("NIM: ").append(mhs.getNim()).append("\n");
            sb.append("Nama: ").append(mhs.getNama()).append("\n");
            sb.append("Alamat: ").append(mhs.getAlamat()).append("\n");
            sb.append("Jenis Kelamin: ").append(mhs.getJenisKelamin()).append("\n");
            sb.append("Phone: ").append(mhs.getPhone()).append("\n");
            sb.append("Prodi: ").append(mhs.getProdi()).append("\n\n");
        }
        
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(500, 400));
        
        JOptionPane.showMessageDialog(this, scrollPane, "Data Mahasiswa", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Method untuk menambah data ke tabel
    private void addToTable(Mahasiswa mhs) {
        Object[] row = {
            mhs.getNim(),
            mhs.getNama(),
            mhs.getAlamat(),
            mhs.getJenisKelamin(),
            mhs.getPhone(),
            mhs.getProdi()
        };
        tableModel.addRow(row);
    }
    
    // Method untuk update tabel
    private void updateTable() {
        tableModel.setRowCount(0);
        for (Mahasiswa mhs : dataMahasiswa) {
            addToTable(mhs);
        }
    }
    
    // Method untuk membersihkan form
    private void clearForm() {
        txtNIM.setText("");
        txtNAMA.setText("");
        txtALAMAT.setText("");
        txtPHONE.setText("");
        txtPRODI.setText("");
        bgJenisKelamin.clearSelection();
        selectedRow = -1;
        tblMahasiswa.clearSelection();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgJenisKelamin = new javax.swing.ButtonGroup();
        txtDATAMAHASISWA = new javax.swing.JLabel();
        rbPria = new javax.swing.JRadioButton();
        rbWanita = new javax.swing.JRadioButton();
        txtNIM = new javax.swing.JTextField();
        txtNAMA = new javax.swing.JTextField();
        txtALAMAT = new javax.swing.JTextField();
        txtPHONE = new javax.swing.JTextField();
        txtPRODI = new javax.swing.JTextField();
        btnSimpan = new javax.swing.JButton();
        btnUbah = new javax.swing.JButton();
        btnHapus = new javax.swing.JButton();
        btnBersihkan = new javax.swing.JButton();
        btnKeluar = new javax.swing.JButton();
        btnCetak = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblMahasiswa = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtDATAMAHASISWA.setText("DATA MAHASISWA");

        rbPria.setText("Pria");

        rbWanita.setText("Wanita");

        txtNIM.setText("jTextField1");

        txtNAMA.setText("jTextField2");

        txtALAMAT.setText("jTextField3");

        txtPHONE.setText("jTextField4");
        txtPHONE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPHONEActionPerformed(evt);
            }
        });

        txtPRODI.setText("jTextField5");

        btnSimpan.setText("SIMPAN");
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });

        btnUbah.setText("UBAH");

        btnHapus.setText("HAPUS");

        btnBersihkan.setText("BERSIHKAN");

        btnKeluar.setText("KELUAR");

        btnCetak.setText("CETAK");

        tblMahasiswa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblMahasiswa);

        jLabel1.setText("NIM");

        jLabel2.setText("NAMA");

        jLabel3.setText("ALAMAT");

        jLabel4.setText("JENIS KELAMIN");

        jLabel5.setText("PHONE");

        jLabel6.setText("PRODI");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6))
                                .addGap(118, 118, 118)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtPRODI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtPHONE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtNIM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(rbPria)
                                            .addComponent(txtNAMA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtALAMAT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(rbWanita)
                                        .addGap(183, 183, 183))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSimpan)
                                .addGap(18, 18, 18)
                                .addComponent(btnUbah)
                                .addGap(18, 18, 18)
                                .addComponent(btnHapus)
                                .addGap(18, 18, 18)
                                .addComponent(btnBersihkan)
                                .addGap(18, 18, 18)
                                .addComponent(btnKeluar)
                                .addGap(18, 18, 18)
                                .addComponent(btnCetak)))))
                .addGap(0, 19, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtDATAMAHASISWA)
                .addGap(236, 236, 236))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(txtDATAMAHASISWA)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNIM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNAMA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtALAMAT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbPria)
                    .addComponent(rbWanita)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPHONE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPRODI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSimpan)
                    .addComponent(btnUbah)
                    .addComponent(btnHapus)
                    .addComponent(btnBersihkan)
                    .addComponent(btnKeluar)
                    .addComponent(btnCetak))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtPHONEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPHONEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPHONEActionPerformed

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSimpanActionPerformed

    /**
     * @param args the command line arguments
     */
   public static void main(String args[]) {
    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            DataMahasiswaForm form = new DataMahasiswaForm();
            form.setVisible(true);
        }
    });
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup bgJenisKelamin;
    private javax.swing.JButton btnBersihkan;
    private javax.swing.JButton btnCetak;
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnKeluar;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton btnUbah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rbPria;
    private javax.swing.JRadioButton rbWanita;
    private javax.swing.JTable tblMahasiswa;
    private javax.swing.JTextField txtALAMAT;
    private javax.swing.JLabel txtDATAMAHASISWA;
    private javax.swing.JTextField txtNAMA;
    private javax.swing.JTextField txtNIM;
    private javax.swing.JTextField txtPHONE;
    private javax.swing.JTextField txtPRODI;
    // End of variables declaration//GEN-END:variables
}
// Tambahkan kode anda disini
